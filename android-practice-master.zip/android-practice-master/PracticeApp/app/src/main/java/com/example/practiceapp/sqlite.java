package com.example.practiceapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cursoradapter.widget.SimpleCursorAdapter;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class sqlite extends AppCompatActivity {

    TextView name;
    Button btn, updatebtn, deletebtn;
    ListView names;
    String selecteditem;

    public class dbo extends SQLiteOpenHelper{

        public dbo(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
            super(context, "Student", factory, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL("create table stud (sid integer primary key autoincrement,sname text)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL("drop table if exists stud");
            onCreate(sqLiteDatabase);
        }

        public void addData(String name){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("sname",name);
            db.insert("stud",null,cv);
            db.close();
        }

        public void deletedata(String name){
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete("stud","sname=?",new String[]{name});
            db.close();
        }

        public void updatedata(String name, String originalname){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues cv = new ContentValues();

            cv.put("sname",name);
            db.update("stud",cv,"sname=?",new String[]{originalname});
            db.close();
        }

        public List<String> getAlldata(){
            List<String> namelist = new ArrayList<>();
            SQLiteDatabase db = this.getWritableDatabase();
            Cursor res = db.rawQuery("select sname from stud",null);

            while(res.moveToNext()){
                namelist.add(res.getString(0));
            }
            return namelist;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqlite);
        name=findViewById(R.id.entername);
        btn=findViewById(R.id.enterdata);
        updatebtn=findViewById(R.id.updatename);
        deletebtn=findViewById(R.id.deletedata);
        names=findViewById(R.id.showdata);
        dbo data = new dbo(this ,"Student",null,1);
         final List<String> namedata = data.getAlldata();
        final ArrayAdapter<String> adp = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,namedata);
        names.setAdapter(adp);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data.addData(name.getText().toString());
                name.setText("");
                namedata.clear();
                namedata.addAll(data.getAlldata());
                adp.notifyDataSetChanged();
                names.invalidateViews();
                names.refreshDrawableState();
            }
        });
        names.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                selecteditem = names.getItemAtPosition(i).toString();
                name.setText(selecteditem);

            }
        });

        updatebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                data.updatedata(name.getText().toString(),selecteditem);
                name.setText("");
                namedata.clear();
                namedata.addAll(data.getAlldata());
                adp.notifyDataSetChanged();
                names.invalidateViews();
                names.refreshDrawableState();
            }
        });

        deletebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alert = new AlertDialog.Builder(sqlite.this);
                alert.setMessage("Are you sure you want to delete the data?");
                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        data.deletedata(name.getText().toString());
                        name.setText("");
                        namedata.clear();
                        namedata.addAll(data.getAlldata());
                        adp.notifyDataSetChanged();
                        names.invalidateViews();
                        names.refreshDrawableState();
                    }
                });

                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog display = alert.create();
                display.show();
            }
        });

    }
}