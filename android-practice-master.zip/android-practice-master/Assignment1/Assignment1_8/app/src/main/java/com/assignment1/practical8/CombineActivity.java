package com.assignment1.practical8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CombineActivity extends AppCompatActivity {


    TextView fullname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_combine);
        fullname=findViewById(R.id.yourname);

        Intent i2 = getIntent();
        String fname = i2.getStringExtra("fname");
        String lname = i2.getStringExtra("lname");

        fullname.setText("Welcome, "+fname+" "+lname);

    }
}