package com.assignment1.practical6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class student_info extends AppCompatActivity {

    TextView name,age,address,city,phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_info);
        name=findViewById(R.id.txtname);
        age=findViewById(R.id.txtage);
        address=findViewById(R.id.txtaddress);
        city=findViewById(R.id.txtcity);
        phone=findViewById(R.id.txtphone);

        Intent i = getIntent();
        name.setText(i.getStringExtra("Name"));
        age.setText(i.getStringExtra("Age"));
        address.setText(i.getStringExtra("Address"));
        city.setText(i.getStringExtra("City"));
        phone.setText(i.getStringExtra("Phone"));
    }
}