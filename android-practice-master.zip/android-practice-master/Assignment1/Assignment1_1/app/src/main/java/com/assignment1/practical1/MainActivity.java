package com.assignment1.practical1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button red, green, blue;
    TextView text;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text=findViewById(R.id.sampletext);

        //RED Color
        red=findViewById(R.id.redbtn);
        red.setBackgroundColor(Color.RED);
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setTextColor(Color.RED);
            }
        });

        //GREEN Color
        green=findViewById(R.id.greenbtn);
        green.setBackgroundColor(Color.GREEN);
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setTextColor(Color.GREEN);
            }
        });

        //BLUE Color
        blue=findViewById(R.id.bluebtn);
        blue.setBackgroundColor(Color.BLUE);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setTextColor(Color.BLUE);
            }
        });
    }
}