package com.example.firstpractical;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Q9 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q9);
    }
}