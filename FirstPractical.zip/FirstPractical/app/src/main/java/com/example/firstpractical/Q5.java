package com.example.firstpractical;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class Q5 extends AppCompatActivity {

    TextView tvExampleText, tvResult,tvCount;
    Button btnValue;
    CheckBox chkJava, chkC, chkCPP, chkPHP, chkPython;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q5);

        tvExampleText = findViewById(R.id.tvExampleText);
        tvResult = findViewById(R.id.tvResult);
        tvCount = findViewById(R.id.tvCount);
        btnValue = findViewById(R.id.btnValue);
        chkJava = findViewById(R.id.chkJava);
        chkC = findViewById(R.id.chkC);
        chkCPP = findViewById(R.id.chkCPP);
        chkPHP = findViewById(R.id.chkPHP);
        chkPython = findViewById(R.id.chkPython);

        btnValue.setOnClickListener(new View.OnClickListener() {

            String Answer="";
            int i = 0;

            @Override
            public void onClick(View view) {
                Answer = "";
                i = 0;
                if(chkJava.isChecked()){
                    Answer += "\n" + chkJava.getText().toString();
                    ++i;
                }
                if(chkC.isChecked()){
                    Answer += "\n" + chkC.getText().toString();
                    ++i;
                }
                if(chkCPP.isChecked()){
                    Answer += "\n" + chkCPP.getText().toString();
                    ++i;
                }
                if(chkPHP.isChecked()){
                    Answer += "\n" + chkPHP.getText().toString();
                    ++i;
                }
                if(chkPython.isChecked()){
                    Answer += "\n" + chkPython.getText().toString();
                    ++i;
                }
                tvResult.setText(Answer);
                tvCount.setText("You have selected "+ i +" items");
            }
        });
    }

    public void backToMenu(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}