package com.example.firstpractical;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Q2 extends AppCompatActivity {

    Button btnSmall, btnMedium, btnLarge;
    TextView tvExampleText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q2);

        tvExampleText = findViewById(R.id.tvExampleText);

        btnSmall = findViewById(R.id.btnSmall);
        btnSmall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvExampleText.setTextSize(10);
            }
        });

        btnMedium = findViewById(R.id.btnMedium);
        btnMedium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvExampleText.setTextSize(25);
            }
        });

        btnLarge = findViewById(R.id.btnLarge);
        btnLarge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvExampleText.setTextSize(40);
            }
        });
    }

    public void backToMenu(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}