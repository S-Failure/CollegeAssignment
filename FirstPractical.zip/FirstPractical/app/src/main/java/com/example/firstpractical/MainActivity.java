package com.example.firstpractical;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnQ1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void openQ1(View view) {
        Intent intent = new Intent(this, Q1.class);
        startActivity(intent);
    }

    public void openQ2(View view) {
        Intent intent = new Intent(this, Q2.class);
        startActivity(intent);
    }

    public void openQ3(View view) {
        Intent intent = new Intent(this, Q3.class);
        startActivity(intent);
    }

    public void openQ4(View view) {
        Intent intent = new Intent(this, Q4.class);
        startActivity(intent);
    }

    public void openQ5(View view) {
        Intent intent = new Intent(this, Q5.class);
        startActivity(intent);
    }

    public void openQ6(View view) {
        Intent intent = new Intent(this, Q6.class);
        startActivity(intent);
    }

    public void openQ7(View view) {
        Intent intent = new Intent(this, Q7.class);
        startActivity(intent);
    }

    public void openQ8(View view) {
        Intent intent = new Intent(this, Q8.class);
        startActivity(intent);
    }

    public void openQ9(View view) {
        Intent intent = new Intent(this, Q9.class);
        startActivity(intent);
    }

    public void openQ10(View view) {
        Intent intent = new Intent(this, Q10.class);
        startActivity(intent);
    }
}