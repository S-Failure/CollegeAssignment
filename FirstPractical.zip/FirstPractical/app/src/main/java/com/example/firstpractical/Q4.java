package com.example.firstpractical;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Q4 extends AppCompatActivity {

    TextView tvAnswer;
    EditText edtValue;
    Button btnAns, btnClear;
    RadioButton rdoC2F,rdoF2C;
    Double x;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q4);

        tvAnswer = findViewById(R.id.tvAnswer);
        edtValue = findViewById(R.id.edtValue);
        rdoC2F = findViewById(R.id.rdoC2F);
        rdoF2C = findViewById(R.id.rdoF2C);
        btnAns = findViewById(R.id.btnAns);
        btnClear = findViewById(R.id.btnClear);

        btnAns.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edtValue.getText().toString().isEmpty()){
                    tvAnswer.setText("Enter Temperature");
                }else{
                    x =
                            Double.parseDouble(String.valueOf(edtValue.getText()));
                    if(rdoC2F.isChecked()){
                        x = (x*9) / 5 + 32;
                        x = Double.parseDouble(new
                                DecimalFormat("##.###").format(x));
                        tvAnswer.setText(String.valueOf(x) + "Degree F");
                    }else if(rdoF2C.isChecked()){
                        x = (x - 32) * 5/9;
                        x = Double.parseDouble(new
                                DecimalFormat("##.###").format(x));
                        tvAnswer.setText(String.valueOf(x) + " Degree C");
                    }else{
                        tvAnswer.setText("Please select an option !");
                    }
                }
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tvAnswer.setText("0.0");
                edtValue.setText("");
                rdoC2F.setChecked(false);
                rdoF2C.setChecked(false);
            }
        });
    }

    public void backToMenu(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}