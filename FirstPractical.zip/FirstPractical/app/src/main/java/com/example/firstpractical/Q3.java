package com.example.firstpractical;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Q3 extends AppCompatActivity {

    double input1 = 0, input2 = 0;
    TextView txt;
    boolean Addition, Subtract, Multiplication, Division, mRemainder, decimal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_q3);

        txt = (TextView) findViewById(R.id.display);
    }

    public void number1(View view){
        txt.setText(txt.getText() + "1");
    }

    public void number2(View view){
        txt.setText(txt.getText() + "2");
    }

    public void number3(View view){
        txt.setText(txt.getText() + "3");
    }

    public void number4(View view){
        txt.setText(txt.getText() + "4");
    }

    public void number5(View view){
        txt.setText(txt.getText() + "5");
    }

    public void number6(View view){
        txt.setText(txt.getText() + "6");
    }

    public void number7(View view){
        txt.setText(txt.getText() + "7");
    }

    public void number8(View view){
        txt.setText(txt.getText() + "8");
    }

    public void number9(View view){
        txt.setText(txt.getText() + "9");
    }

    public void number0(View view){
        txt.setText(txt.getText() + "0");
    }

    public void add(View view){
        if (txt.getText().length() != 0) {
            input1 = Float.parseFloat(txt.getText() + "");
            Addition = true;
            decimal = false;
            txt.setText(null);
        }
    }

    public void sub(View view){
        if (txt.getText().length() != 0) {
            input1 = Float.parseFloat(txt.getText() + "");
            Subtract = true;
            decimal = false;
            txt.setText(null);
        }
    }

    public void mul(View view){
        if (txt.getText().length() != 0) {
            input1 = Float.parseFloat(txt.getText() + "");
            Multiplication = true;
            decimal = false;
            txt.setText(null);
        }
    }

    public void div(View view){
        if (txt.getText().length() != 0) {
            input1 = Float.parseFloat(txt.getText() + "");
            Division = true;
            decimal = false;
            txt.setText(null);
        }
    }

    public void equal(View view){
        if (Addition || Subtract || Multiplication || Division || mRemainder) {
            input2 = Float.parseFloat(txt.getText() + "");
        }

        if (Addition) {

            txt.setText(input1 + input2 + "");
            Addition = false;
        }

        if (Subtract) {

            txt.setText(input1 - input2 + "");
            Subtract = false;
        }

        if (Multiplication) {
            txt.setText(input1 * input2 + "");
            Multiplication = false;
        }

        if (Division) {
            txt.setText(input1 / input2 + "");
            Division = false;
        }
        if (mRemainder) {
            txt.setText(input1 % input2 + "");
            mRemainder = false;
        }
    }

    public void dot(View view){
        if (decimal) {
        } else {
            txt.setText(txt.getText() + ".");
            decimal = true;
        }
    }

    public void remind(View view){
        if (txt.getText().length() != 0) {
            input1 = Float.parseFloat(txt.getText() + "");
            mRemainder = true;
            decimal = false;
            txt.setText(null);
        }
    }

    public void del(View view){
        txt.setText("");
        input1 = 0.0;
        input2 = 0.0;
    }

}